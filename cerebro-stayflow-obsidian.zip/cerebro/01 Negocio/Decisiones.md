---
tipo: registro
actualizado: 2026-11-12
---
# Registro de decisiones

> Formato: **fecha · decisión** — por qué · alternativas · estado. No se borran; se marcan como reemplazadas.

- **2026-11 · Pago único, sin mensualidad** — encaja con el público y simplifica la venta. Alternativa: suscripción. Vigente.
- **2026-11 · Solo vender lo que existe; lo demás "Próximamente"** — evita reclamos y mide demanda con "Avísame". Alternativa: preventa (descartada por riesgo de reembolsos). Vigente.
- **2026-11 · Modelo en línea; instalador = envoltorio** — un solo código, sin migraciones. Alternativa: programa sin internet (descartada por ahora: sin celular, rompe guía/QR/equipo, más soporte). Vigente.
- **2026-11 · Profit se llama ahora Business** — nombre más amplio (ingresos, gastos, ganancia). Ids internos siguen `profit`. Vigente.
- **2026-11 · Packs: Esencial y Megapack (todas las apps a la venta)** — el "Profesional" duplicaba contenido. Vigente.
- **2026-11 · "De por vida" → 12 meses de actualizaciones + renovación opcional USD 10/año** — sostenibilidad. La app **nunca se bloquea** por no renovar. Vigente. Pendiente: mecanismo técnico.
- **2026-11 · Landing como embudo alrededor de Host** — una promesa, 6.500 px. Vigente. Ver [[Landing - estructura y copy]].
- **2026-11 · Promoción única solo con cierre real** — nada de urgencia falsa (Meta y ley). Vigente.
- **2026-11 · Garantía de 14 días** — supuesto propio. `[VERIFICAR con abogado]`.
- **2026-11-12 · Sin prueba gratis; acceso por código de licencia** — el producto se vende con pago único y garantía de 14 días, no con prueba. Cada compra entrega un código `SF-XXXX-XXXX-XXXX` (uno o varios productos) que el cliente pega al entrar; se activa al instante, no vence y registra 12 meses de actualizaciones (`updates_until`). Alternativas: prueba de 14 días (descartada), cuenta creada por webhook (queda para cuando exista el cobro). Vigente.
- **2026-11-12 · Registro sin confirmar el correo** — el cliente entra directo tras llenar el formulario (Confirm email apagado en Supabase); se pide el correo dos veces. Falta captcha antes de abrirlo al público. Vigente.
